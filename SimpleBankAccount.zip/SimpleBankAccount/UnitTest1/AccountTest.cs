﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SimpleBankAccount;

namespace UnitTest1
{
    [TestClass]
    public class AccountTest
    {
        [TestMethod]
        public void Test_Deposit_Valid_Ammount()
        {
            Account testAccount = new Account();
            testAccount.Deposit(2000);
            Assert.AreEqual(testAccount.Balance, 2000);
        }

        [TestMethod]
        public void Test_Withdraw_Valid_Ammount()
        {
            Account testAccount = new Account();
            testAccount.Deposit(1000);
            testAccount.Withdraw(300);
            Assert.AreEqual(testAccount.Balance, 700);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Test_Deposit_InValid_Amount()
        {
            Account testAccount = new Account();
            testAccount.Deposit(-100);
            Assert.Fail();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Test_Withdraw_InValid_Amount_OverWithdraw()
        {
            Account testAccount = new Account();
            testAccount.Deposit(1000);
            testAccount.Withdraw(3000);
            Assert.Fail();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Test_Withdraw_InValid_Amount_NegativeWithdraw()
        {
            Account testAccount = new Account();
            testAccount.Deposit(1000);
            testAccount.Withdraw(-500);
            Assert.Fail();
        }
    }
}
