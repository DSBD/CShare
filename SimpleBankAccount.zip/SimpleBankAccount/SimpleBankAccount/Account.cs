﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleBankAccount
{
    public class Account
    {
        private List<Transaction> transactionList = new List<Transaction>();
        private decimal _balance;

        public decimal Balance
        {
            get
            {
                decimal _balance = 0;

                foreach (Transaction curTransaction in transactionList)
                {
                    if (curTransaction.type == Transaction.TransactionType.Deposit)
                    {
                        _balance += curTransaction.TransactionAmmount;
                    }
                    else if (curTransaction.type == Transaction.TransactionType.Withdraw)
                    {
                        _balance -= curTransaction.TransactionAmmount;
                    }
                }

                return _balance;
            }
        }

        public void Withdraw(decimal amount)
        {
            if (amount > Balance)
            {
                throw new ArgumentException("Amount Should be Less than or Equal to Balance");
            }

            if (amount < 0)
            {
                throw new ArgumentException("Amount Should be Greater than 0");
            }

            Transaction withdraw = new Transaction(Transaction.TransactionType.Withdraw, amount);
            transactionList.Add(withdraw);
        }

        public void Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Amount Should be Positive");
            }

            Transaction deposit = new Transaction(Transaction.TransactionType.Deposit, amount);
            transactionList.Add(deposit);
        }

        public void TransferFunds()
        {
            //Blank
        }
    }
}
