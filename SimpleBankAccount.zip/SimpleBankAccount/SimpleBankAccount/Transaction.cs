﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleBankAccount
{
    public class Transaction
    {
        public enum TransactionType
        {
            Deposit,
            Withdraw
        }

        public TransactionType type;

        public Transaction(TransactionType tType, decimal Ammount)
        {
            type = tType;
            TransactionAmmount = Ammount;
        }       

        private decimal _amount;

        public decimal TransactionAmmount
        {
            get { return _amount; }
            set { _amount = value; }
        }
    }
}
