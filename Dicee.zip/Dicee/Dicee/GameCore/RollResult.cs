﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dicee.GameCore
{
    class RollResult
    {
        public int[] Dice { get; set; }
        public int RoundScore { get; set; }
        public int TotalScore { get; set; }
    }
}
