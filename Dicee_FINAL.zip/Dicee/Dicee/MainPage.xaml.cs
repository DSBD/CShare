﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Dicee.GameCore;

namespace Dicee
{
    public sealed partial class MainPage : Page
    {
        private Game _game;

        public MainPage()
        {
            this.InitializeComponent();
            _game = new Game();
        }

        private void RollButton_Click(object sender, RoutedEventArgs e)
        {
            RollResult result = _game.Roll();
            //DiceText.Text = $"{result.Dice[0]} {result.Dice[1]} {result.Dice[2]}";

            Die1.DisplayFace(result.Dice[0]);
            Die2.DisplayFace(result.Dice[1]);
            Die3.DisplayFace(result.Dice[2]);

            TurnScore.Text = $"Round Score: {result.RoundScore}";
            TotalScore.Text = $"Score: {result.TotalScore}";
        }

        
    }
}
