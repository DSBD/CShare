﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dicee.GameCore
{
    class Game
    {
        Random randGen = new Random();
        private int[] _dice { get; set; }
        private int _roundScore { get; set; }
        private int _totalScore { get; set; }

        public Game()
        {
            _dice = new int[3];
        }

        public RollResult Roll()
        {
            GenerateRandomDice();
            UpdateScore();

            return new RollResult
            {
                Dice = _dice,
                RoundScore = _roundScore,
                TotalScore = _totalScore,
            };

        }

        private void GenerateRandomDice()
        {
            for (int i = 0; i < _dice.Length; i++)
            {
                _dice[i] = randGen.Next(1, 7);
            }
        }

        private void UpdateScore()
        {
            if (_dice[0] == _dice[1] && _dice[0] == _dice[2])
            {
                if (_dice[0] == 6)
                {
                    _roundScore = 1000;
                }
                else
                {
                    _roundScore = 100 * _dice[0];
                }
            }

            else if (_dice[0] == _dice[1] || _dice[1] == _dice[2] || _dice[2] == _dice[0])
            {
                _roundScore = 50;
            }

            else
            {
                _roundScore = 0;
            }

            _totalScore += _roundScore;
        }
    }
}
