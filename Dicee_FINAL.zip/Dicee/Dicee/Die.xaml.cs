﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace Dicee
{
    public sealed partial class Die : UserControl
    {
        public Die()
        {
            this.InitializeComponent();
        }

        public void DisplayFace(int faceNumber)
        {
            Face_1.Visibility = Visibility.Collapsed;
            Face_2.Visibility = Visibility.Collapsed;
            Face_3.Visibility = Visibility.Collapsed;
            Face_4.Visibility = Visibility.Collapsed;
            Face_5.Visibility = Visibility.Collapsed;
            Face_6.Visibility = Visibility.Collapsed;

            switch (faceNumber)
            {
                case 1:
                    Face_1.Visibility = Visibility.Visible;
                    break;
                case 2:
                    Face_2.Visibility = Visibility.Visible;
                    break;
                case 3:
                    Face_3.Visibility = Visibility.Visible;
                    break;
                case 4:
                    Face_4.Visibility = Visibility.Visible;
                    break;
                case 5:
                    Face_5.Visibility = Visibility.Visible;
                    break;
                case 6:
                    Face_6.Visibility = Visibility.Visible;
                    break;
            }
        }
    }
}
