﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;

namespace Movie_Databinding
{
    public class Movie
    {
        public string Title { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; }
        public Image Poster { get; set; }
        public string Year
        {
            get
            {
                return $"({Date.Year})";
            }
        }

        public Movie(string Title, DateTime Date, string Description, string ImgSource)
        {
            this.Title = Title;
            this.Date = Date;
            this.Description = Description;
            this.Poster = new Image();
            Poster.Source = new BitmapImage(new Uri($"ms-appx:///Assets/{ImgSource}", UriKind.RelativeOrAbsolute));
        }

        public static List<Movie> AllMovies()
        {
            List<Movie> movieList = new List<Movie>
            {
                new Movie(Title: "Star Trek: Generations", Date: new DateTime(1994, 11, 17), Description: "Captain Jean-Luc Picard and the crew of the Enterprise-D find themselves at odds with the renegade scientist Soran who is destroying entire star systems. Only one man can help Picard stop Soran's scheme...and he…", ImgSource: "ST_Generations.jpg"),

                new Movie(Title: "Star Trek: First Contact", Date: new DateTime(1996, 11, 21), Description: "The Borg, a relentless race of cyborgs, are on a direct course for Earth. Violating orders to stay away from the battle, Captain Picard and the crew of the newly-commissioned USS Enterprise E pursue the Borg back…", ImgSource: "ST_First_Contact.jpg"),

                new Movie(Title: "Star Trek: Insurrection", Date: new DateTime(1998, 12, 10), Description: "When an alien race and factions within Starfleet attempt to take over a planet that has regenerative properties, it falls upon Captain Picard and the crew of the Enterprise to defend the planet's people as well…", ImgSource: "ST_Insurrection.jpg"),

                new Movie(Title: "Star Trek: Nemesis", Date: new DateTime(2002, 12, 13), Description: "En route to the honeymoon of William Riker to Deanna Troi on her home planet of Betazed, Captain Jean-Luc Picard and the crew of the U.S.S. Enterprise receives word from Starfleet that a coup has resulted in the…", ImgSource: "ST_Nemesis.jpg")
            };
            return movieList;
        }
    }
};